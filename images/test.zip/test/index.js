let slideIndex = 0;
const slides = document.querySelectorAll('.image-container img');
const totalSlides = slides.length;

document.querySelector('.next').addEventListener('click', function() {
    moveSlide(1);
});

document.querySelector('.prev').addEventListener('click', function() {
    moveSlide(-1);
});

function moveSlide(step) {
    slideIndex += step;
    if (slideIndex < 0) slideIndex = totalSlides - 1;
    if (slideIndex >= totalSlides ) slideIndex = 0;
    document.querySelector('.image-container').style.transform = 'translateX(' + (-slideIndex * 100) + '%)';
}

// Automatic slide
setInterval(function() {
    moveSlide(1);
}, 3000); // Change image every 3 seconds

function scroll(direction) {
    var container = document.querySelector('.card-wrapper');
    var scrollAmount = container.scrollWidth / container.childElementCount;
    if (direction === -1) {
        container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
        container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
}

